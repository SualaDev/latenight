<template>
  <div class="content">
      <nuxt-link to="/"
        ><div class="menu">
          <img src="@/assets/images/home.svg" alt="home" />
          <p>Dashboard</p>
        </div></nuxt-link
      >
      <nuxt-link to="/customers"
        ><div class="menu">
          <img src="@/assets/images/customer.svg" alt="home" />
          <p>Customers</p>
        </div></nuxt-link
      >
      <nuxt-link to="/candidates"
        ><div class="menu">
          <img src="@/assets/images/candidates.svg" alt="home" />
          <p>Candidates</p>
        </div></nuxt-link
      >
      <nuxt-link to="/requests"
        ><div class="menu">
          <img src="@/assets/images/requests.svg" alt="home" />
          <p>Requests</p>
        </div></nuxt-link
      >
      <nuxt-link to="/payment"
        ><div class="menu">
          <img src="@/assets/images/payments.svg" alt="home" />
          <p>Payment</p>
        </div></nuxt-link
      >
      <nuxt-link to="/reviews"
        ><div class="menu">
          <img src="@/assets/images/reviews.svg" alt="home" />
          <p>Reviews</p>
        </div></nuxt-link
      >
      <nuxt-link to="/settings"
        ><div class="menu">
          <img src="@/assets/images/settings.svg" alt="home" />
          <p>Settings</p>
        </div></nuxt-link
      >
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>
.side-menu {
  position: fixed;
  min-width: 245px;
  height: 100%;
  background-color: white;
  padding-top: 74px;
}

.menu {
  display: flex;
  align-items: center;
  /* margin-bottom: 10px; */
  height: 60px;
  cursor: pointer;
}

.menu img {
  padding: 20px 20px 20px 32px;
}

.menu p {
  color: #6f8a9c;
  padding: 0 16px;
  height: 60px;
  display: flex;
  align-items: center;
  font-size: 15px;
  margin-bottom: 0;
}

a.nuxt-link-exact-active .menu,
a:hover .menu {
  background-color: rgba(4, 37, 56, 0.076);
}

a.nuxt-link-exact-active p,
a:hover p {
  color: #010025;
  font-weight: 600;
}

a.nuxt-link-exact-active img,
a:hover img {
  background-color: #010025;
  border-radius: 0 20px 20px 0;
}

a{
  margin-bottom: 5px;
}
a:last-child{
  margin-bottom: 0;
}
.content{
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding-top: 74px;
  }
</style>